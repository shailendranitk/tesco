cd src
javac -d WEB-INF/classes com/myapp/model/Record.java
javac -classpath WEB-INF/lib/*:WEB-INF/classes -d WEB-INF/classes com/barcode/BarcodeGeneratorServlet.java

jar -cvf ROOT.war *.jsp images css js WEB-INF .ebextensions
cp ROOT.war /Library/Tomcat/webapps