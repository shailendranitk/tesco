package com.barcode;

import java.awt.image.BufferedImage;
import java.io.BufferedOutputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.jasperreports.components.barbecue.BarcodeInfo;
import net.sf.jasperreports.components.barbecue.BarcodeProviders.Barcode3of9Provider;
import net.sourceforge.barbecue.Barcode;
import net.sourceforge.barbecue.BarcodeException;
import net.sourceforge.barbecue.BarcodeImageHandler;
import net.sourceforge.barbecue.output.OutputException;

/**
 * This class is to return an order object after processing all full returns.
 * 
 */
public class BarcodeGeneratorServlet extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * This method take original order and return request.
	 * 
	 */
	@Override
	public void service(final HttpServletRequest pRequest, final HttpServletResponse pResponse) throws ServletException, IOException {
		final String orderId = pRequest.getParameter("orderid");

		final String imageType = "JPG";
		//final byte[] biteArray = null;
		ByteArrayOutputStream baos = null;
		final Barcode3of9Provider barcode3of9 = new Barcode3of9Provider();
		//final Base64 base64 = new Base64();
		final BarcodeInfo barcodeInfo = new BarcodeInfo();
		barcodeInfo.setCode(orderId.toUpperCase());
		Barcode imageb;
		BufferedImage bimage = null;
		try {
			imageb = barcode3of9.createBarcode(barcodeInfo);

			bimage = BarcodeImageHandler.getImage(imageb);
			baos = new ByteArrayOutputStream();
			ImageIO.write(bimage, imageType, baos);
			final byte[] imageByteArr = baos.toByteArray();
			final String name = "barcode-01";

			//check if we are setting the correct mime type based on the image format like image/jpeg or image/gif or image/png etc. (refer code snippet below for checking the image format)
			//			pResponse.setContentType("image/jpeg"); 
			pResponse.setContentType("image/png");

			//check the byte array size which would be same as the image size
			pResponse.setContentLength(imageByteArr.length);
			pResponse.setHeader("Content-Disposition", "inline; filename=\"" + name + "\"");

			BufferedOutputStream output = null;

			output = new BufferedOutputStream(pResponse.getOutputStream());
			output.write(imageByteArr);
			output.flush();

		} catch (final BarcodeException e) {
			e.printStackTrace();
		} catch (final OutputException e) {
			e.printStackTrace();
		}catch (final Exception e) {
			e.printStackTrace();
		}

	}

	/*private byte[] produceBarcodeByteArray(final String orderId) {
		final String imageType = "JPG";
		byte[] biteArray = null;
		ByteArrayOutputStream baos = null;
		final Barcode3of9Provider barcode3of9 = new Barcode3of9Provider();
		final Base64 base64 = new Base64();
		final BarcodeInfo barcodeInfo = new BarcodeInfo();
		barcodeInfo.setCode(orderId.toUpperCase());
		Barcode imageb;
		BufferedImage bimage = null;
		try {
			imageb = barcode3of9.createBarcode(barcodeInfo);

			bimage = BarcodeImageHandler.getImage(imageb);
			baos = new ByteArrayOutputStream();
		} catch (final BarcodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final OutputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ImageIO.write(bimage, imageType, baos);

				baos.flush();
				biteArray = baos.toByteArray();
				baos.close();
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return biteArray;

	}*/

	/*private String produceBarcode(final String orderId) {
		final String imageType = "JPG";
		byte[] biteArray = null;
		ByteArrayOutputStream baos = null;
		final Barcode3of9Provider barcode3of9 = new Barcode3of9Provider();
		final Base64 base64 = new Base64();
		final BarcodeInfo barcodeInfo = new BarcodeInfo();
		barcodeInfo.setCode(orderId.toUpperCase());
		Barcode imageb;
		BufferedImage bimage = null;
		try {
			imageb = barcode3of9.createBarcode(barcodeInfo);

			bimage = BarcodeImageHandler.getImage(imageb);
			baos = new ByteArrayOutputStream();
		} catch (final BarcodeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (final OutputException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			try {
				ImageIO.write(bimage, imageType, baos);

				baos.flush();
				biteArray = baos.toByteArray();
				baos.close();
			} catch (final IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		String str = null;
		try {
			str = new String(biteArray, "UTF-8");
		} catch (final UnsupportedEncodingException e) {

			e.printStackTrace();
		}
		return str;

		//		return base64.encodeToString(biteArray);

	}*/

	
	
}
